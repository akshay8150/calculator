// Get references to the form and calculator container
const loginForm = document.getElementById('loginForm');
const calculatorContainer = document.getElementById('calculatorContainer');
const resultDisplay = document.getElementById('result');

// Calculator state variables
let currentInput = '';
let operation = '';
let firstOperand = null;

// Handle form submission
loginForm.addEventListener('submit', function (event) {
  event.preventDefault(); // Prevent default form submission

  // Get form values
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Basic validation (optional)
  if (username && password) {
    // Hide the form container and show the calculator container
    document.querySelector('.form-container').style.display = 'none';
    calculatorContainer.style.display = 'block';
  } else {
    alert('Please enter both username and password.');
  }
});

// Calculator functions
function clearDisplay() {
  currentInput = '';
  firstOperand = null;
  operation = '';
  resultDisplay.value = '0';
}

function toggleSign() {
  currentInput = (parseFloat(currentInput) * -1).toString();
  resultDisplay.value = currentInput;
}

function appendValue(value) {
  if (currentInput === '0') {
    currentInput = value;
  } else {
    currentInput += value;
  }
  resultDisplay.value = currentInput;
}

function performOperation(op) {
  if (firstOperand === null) {
    firstOperand = parseFloat(currentInput);
    currentInput = '';
  }
  operation = op;
}

function calculateResult() {
  if (firstOperand !== null && operation !== '') {
    let secondOperand = parseFloat(currentInput);
    let result = 0;

    switch (operation) {
      case '+':
        result = firstOperand + secondOperand;
        break;
      case '-':
        result = firstOperand - secondOperand;
        break;
      case '*':
        result = firstOperand * secondOperand;
        break;
      case '/':
        result = firstOperand / secondOperand;
        break;
      case 'sin(':
        result = Math.sin(firstOperand);
        break;
      case 'cos(':
        result = Math.cos(firstOperand);
        break;
      case 'tan(':
        result = Math.tan(firstOperand);
        break;
      case 'log(':
        result = Math.log10(firstOperand);
        break;
      case 'sqrt(':
        result = Math.sqrt(firstOperand);
        break;
      case 'exp(':
        result = Math.exp(firstOperand);
        break;
      case 'pi':
        result = Math.PI;
        break;
      case 'e':
        result = Math.E;
        break;
      case '^':
        result = Math.pow(firstOperand, secondOperand);
        break;
      default:
        break;
    }

    resultDisplay.value = result;
    firstOperand = null;
    operation = '';
    currentInput = result.toString();
  }
}
